<!--  contact_form.tpl -->
 <!-- contact-us -->
            <article id="feedback">
                <div class="page-section" data-background-color="#f9f9f9">
                    
                    <!-- форма связи -->
                    <div class="container">
                        <div class="col-sm-12">
                            <h2 class="text-center text-uppercase mb27 mt-xs60 mt-sm20"><?php echo siteinfo('siteinfo_transl-contactus')?></h2> </div>
                        <div class="col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1" style="margin-top:50px">
                        <!-- header.tpl -->
            <?php $this->include_tpl('feedback/feedback', '/var/www/admin/data/www/platforme411.naddaka.com/templates/brainwave'); ?>
                    </div>
                  </div>
 			
                </div>
                <!-- .page-section -->
            </article><?php $mabilis_ttl=1507625144; $mabilis_last_modified=1507531800; ///var/www/admin/data/www/platforme411.naddaka.com/templates/brainwave/contact_form.tpl ?>