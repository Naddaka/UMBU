<script>
langs["Edit menu item"] = '<?php echo addslashes(lang("Edit menu item", "admin_menu", FALSE))?>';
langs["Insert menu item before current"] = '<?php echo addslashes(lang("Insert menu item before current", "admin_menu", FALSE))?>';
langs["Insert menu item after current"] = '<?php echo addslashes(lang("Insert menu item after current", "admin_menu", FALSE))?>';
langs["Insert divider before menu item"] = '<?php echo addslashes(lang("Insert divider before menu item", "admin_menu", FALSE))?>';
langs["Insert divider after menu item"] = '<?php echo addslashes(lang("Insert divider after menu item", "admin_menu", FALSE))?>';
langs["Delete menu item"] = '<?php echo addslashes(lang("Delete menu item", "admin_menu", FALSE))?>';
</script><?php $mabilis_ttl=1507655565; $mabilis_last_modified=1499698145; //application/modules/admin_menu/assets/jsLangs.tpl ?>