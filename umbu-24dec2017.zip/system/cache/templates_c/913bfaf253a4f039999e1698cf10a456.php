<link rel="icon" type="image/vnd.microsoft.icon" href="<?php echo siteinfo('siteinfo_favicon_url')?>" />
<link rel="SHORTCUT ICON" href="<?php echo siteinfo('siteinfo_favicon_url')?>"/>

<!-- <link rel="apple-touch-icon" sizes="57x57" href="/uploads/favicon/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/uploads/favicon/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/uploads/favicon/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/uploads/favicon/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/uploads/favicon/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/uploads/favicon/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/uploads/favicon/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/uploads/favicon/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/uploads/favicon/apple-touch-icon-180x180.png">
<link rel="icon" type="image/png" href="/uploads/favicon/favicon-32x32.png" sizes="32x32">
<link rel="icon" type="image/png" href="/uploads/favicon/android-chrome-192x192.png" sizes="192x192">
<link rel="icon" type="image/png" href="/uploads/favicon/favicon-96x96.png" sizes="96x96">
<link rel="icon" type="image/png" href="/uploads/favicon/favicon-16x16.png" sizes="16x16">
<link rel="manifest" href="/uploads/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="msapplication-TileImage" content="/uploads/favicon/mstile-144x144.png"> --><?php $mabilis_ttl=1507625144; $mabilis_last_modified=1507531800; ///var/www/admin/data/www/platforme411.naddaka.com/templates/brainwave/favicon.tpl ?>