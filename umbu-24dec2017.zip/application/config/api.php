<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['mod_search_api_url'] = 'http://requests.imagecms.net/index.php/modules';
$config['imagecms_latest_news'] = 'http://requests.imagecms.net/index.php/news';

/* End of file api.php */
